crack = '*&0*********0*********0*********00000*********0******0000******0*********0*0000****000**0********$0*'
def run(s, list1):
    l = input()
    flag = 0
    for i in l:
        if i == 'd' and list1[s + 1] == '0':
            s += 1
            continue
        if i == 'a' and list1[s - 1] == '0':
            s -= 1
            continue
        if i == 's' and list1[s + 10] == '0':
            s += 10
            continue
        if i == 'w' and list1[s - 10] == '0':
            s -= 10
            continue
        if i == 'a' and list1[s - 1] == '$':
            flag = 1
            continue
        flag = 2
    if flag == 0:
        print('oh wrong')
    elif len(l) != 25:
        print('wrong format1')
    elif flag == 1:
        print('you solved, flag is AGCTF{your input}')
    else:
        print('wrong format2')
if __name__ == '__main__':
    crack_list = list(crack)
    s = crack_list.index('&')
    run(s, crack_list)